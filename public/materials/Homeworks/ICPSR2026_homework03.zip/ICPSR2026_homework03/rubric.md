# Homework 3 Grading Guide

The assignment is graded from 0 to 3.

- **3:** All four tasks are complete, technically correct, and explained clearly using students' friendship-rating actions. The interpretation distinguishes source effects, target effects, dyadic covariates, and remaining model misfit.
- **2:** All four tasks are attempted and the main interpretations are correct, with only minor omissions or unclear wording.
- **1:** The assignment is incomplete or several answers repeat output without explaining what it means for the friendship ratings.
- **0:** No meaningful submission.
