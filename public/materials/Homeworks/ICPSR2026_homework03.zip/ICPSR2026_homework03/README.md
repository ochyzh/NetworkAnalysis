# Homework 3: The Social Relations Model

This is the student assignment for Homework 3. It uses friendship ratings among 32 Dutch university students to practice interpreting a directed Social Relations Model.

Students complete four short tasks:

1. Read a directed friendship rating.
2. Interpret source and target effects using the actions in the data.
3. Interpret two adjusted covariate associations.
4. Assess what the SRM reproduces and what it still misses.

The fitted model is included in `cache/hwSRM.rda`, so students do not need to wait for MCMC estimation. They should open `hw3_srm.qmd`, replace the four answer prompts, render the document, and submit both the completed QMD and HTML files.

The assignment requires `lame` 1.3.4 or later, plus `ggplot2`, `patchwork`, `digest`, and `coda`.
