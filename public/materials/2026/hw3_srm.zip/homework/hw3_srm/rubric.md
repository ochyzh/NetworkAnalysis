# HW 3 (Social Relations Model): Grading Rubric

Consistent with the syllabus's per-assignment scale:

> **0**: No submission
> **1**: Does not demonstrate comprehension of the methodology
> **2**: Adequate comprehension demonstrated
> **3**: Excellent comprehension demonstrated

A student earns a grade for the assignment as a whole, not point-by-point.
The descriptors below say what each grade looks like on *this* assignment
so grading is consistent across the 37-student, 26-remote cohort. The
required part (Q1–Q5) is the basis for a 2; strong stretch work and a
sharper interpretation are what lift a 2 to a 3.

---

## 3: Excellent Comprehension

Everything runs from a clean session, and the interpretation is precise:

- **Variance decomposition (Q2).** Reads all five components correctly,
  keeps variances, covariances, and correlations on compatible scales,
  and separates the largest variance share (`ve`) from the largest
  induced outcome correlation (reciprocal dyads). Translates each
  parameter into a sentence about students and ratings, and notices that
  `cab > 0` means warm raters tend also to be popular.
- **Covariates (Q3).** States which intervals clear zero, and reads
  the paired `male_col - male_row` posterior contrast. Notes that the
  receiving-side effect clears zero but the direct contrast's 95%
  interval includes zero, so the asymmetry is suggestive rather than
  decisive. Explains that an undirected model could not estimate the two
  roles separately, and does not oversell the non-credible coefficients
  (`smoker`, `same_smoker`).
- **Fit (Q4).** Identifies `trans.dep`/`cycle.dep` as the misfit and
  explains **why an additive model must miss transitivity** (a row effect
  is one number for all of an actor's partners; triangles need a third
  actor), connecting it forward to the latent-space/factor models.
- **SRM versus OLS (Q5).** Ties the nodal-interval widening to **effective
  information** (actor-level covariates repeat across dyads), names
  `male_row`, `smoker_row`, and `smoker_col` as losing 95% interval
  clearance, treats the nearly unchanged dyadic widths as a result of
  this fit rather than a universal independence claim, keeps the width
  story separate from the point-estimate story, and resists the "SRM
  just inflates SEs" shorthand.
- **Stretch.** At least one stretch done correctly, with a real
  conclusion (e.g., S1: `dyad.dep` breaks yet coefficients barely move,
  *and* an explanation of why; or S2: `trans.dep` drops sharply under
  `R = 2` with a sentence on what the latent coordinates do).

## 2: Adequate Comprehension

The required tasks are attempted and mostly correct, but the reading
stays at the surface. Typical of a 2:

- Reports the five variance components and the coefficient table
  correctly, but only as numbers ("`va` is 0.13") without the substantive
  translation, or ranks a correlation and raw variances by comparing
  their printed magnitudes rather than moving to a common scale.
- Notes the nodal intervals widened but attributes it vaguely to "network
  dependence" rather than effective sample size; misses that a point
  estimate (`same_program`) also moved or that three nodal intervals stop
  clearing zero.
- Identifies the GOF misfit but calls it a convergence/tuning problem
  rather than a structural limit of the additive model.
- Little or no stretch, or a stretch that runs but is not interpreted.

## 1: Does Not Demonstrate Comprehension

Submitted, but the methodology is not understood. Examples:

- Interprets the SRM as if the rows were independent, or reads a
  non-credible coefficient (e.g. `smoker`) as a real effect.
- Confuses sender and receiver effects, or reciprocity with the
  sender–receiver covariance.
- Reports GOF as "good fit" without noticing the transitivity failure, or
  concludes the SRM "made the SEs worse" as if that were a flaw.
- Code does not run, or the results are inconsistent with the model.

## 0: No Submission

---

## Grading notes and common issues

- **The assignment intentionally uses the default `gof_plot()` statistics.** In
  `lame` 1.3.2, both `gof_plot(fit)` and an explicit supported
  `statistics =` selection work. The assignment calls `gof_plot(fit)` because
  it needs all five default statistics.
- **`R = 0` fits have no `U`/`V`.** For Q2, actor effects come from
  `fit$APM` / `fit$BPM` (named by actor), **not** `rownames(fit$U)`.
  Students who reach for `U` on the pure SRM will get `NULL`.
- **Stretch S2 (`R > 0`):** the course uses
  `tcrossprod(fit$U, fit$V)` as a transparent and backward-compatible
  reconstruction of the multiplicative effects. `lame` 1.3.2 also populates
  `fit$UVPM`; the GOF numbers the task asks for do not depend on this choice.
- **The point estimates barely move in S1 here** (unlike the trade
  example in lecture). That is correct for this dataset and is itself a
  strong observation: reward the student who explains *why* (reciprocity
  is a dyadic error structure, so it always wrecks `dyad.dep`, but only
  distorts coefficients when the dyadic covariates correlate with the
  reciprocated structure, which they don't here).
- **Reproducibility.** Everything is seeded (`6886`) and cached; a correct
  submission reproduces the key's numbers exactly. Divergent numbers
  usually mean the actor ordering was not aligned (`Y` versus `Xn`/`Xd`) or
  the fit was run unseeded.

A worked solution with the target numbers is in
`hw3_srm_solutions.qmd` and `.html`.
