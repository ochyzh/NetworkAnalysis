#############################################################
# _hw3_helpers.R -- everything hw3 needs, in one place.
#
# This homework folder is meant to be self-contained: unzip it,
# open the .qmd, and it runs. So the helpers live here rather than
# reaching back to the course's shared ../../_setup.R. They are the
# SAME idioms you saw on the SRM day (cache_fit, ess, coef_tbl,
# compare_fits), plus two SRM-specific tables (vc_tbl, ppsd).
#
# Nothing here installs anything or reaches outside this folder.
#############################################################

# ----------------------------------------------------------
# cache_fit() -- the caching pattern from the SRM day.
#
# The real ame() call stays visible on screen; there is no hidden
# second version of the model that actually ran. cache_fit hashes the
# code you pass it, and:
#   1. if cache/<name>.rda exists AND the hash matches -> load it
#   2. otherwise fit, save, and report how long it took
# So the first render pays for the fits; every render after loads them
# in milliseconds. Edit a model and the cache invalidates itself.
# Delete cache/ to force honest refits.
# ----------------------------------------------------------
cache_fit <- function(name, expr, dir = "cache", refresh = FALSE) {
  if (!dir.exists(dir)) dir.create(dir, recursive = TRUE)
  path <- file.path(dir, paste0(name, ".rda"))
  code_hash <- substr(digest::digest(deparse(substitute(expr))), 1, 8)

  if (!refresh && file.exists(path)) {
    e <- new.env(); load(path, envir = e)
    if (identical(e$.hash, code_hash)) {
      message("cache hit: '", name, "'"); return(e$.value)
    }
    message("cache STALE for '", name, "' (code changed) -- refitting")
  }
  message("fitting '", name, "' ...")
  t0 <- Sys.time()
  .value <- force(expr)
  .hash  <- code_hash
  save(.value, .hash, file = path)
  message("  done in ",
          round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1),
          "s -> ", path)
  .value
}

# ----------------------------------------------------------
# ess() -- effective sample size per beta, rounded. First thing you
# check after an MCMC fit: did the chain actually move?
# ----------------------------------------------------------
ess <- function(fit) round(coda::effectiveSize(coda::mcmc(fit$BETA)))

# ----------------------------------------------------------
# coef_tbl() -- lame::tidy(), printed the way we read it: point
# estimate, 95% interval, and a flag for whether the interval clears
# zero (i.e. is credibly different from zero).
# ----------------------------------------------------------
coef_tbl <- function(fit, digits = 3) {
  t <- lame::tidy(fit)
  data.frame(
    term = t$term,
    est  = round(t$estimate,  digits),
    lo   = round(t$conf.low,  digits),
    hi   = round(t$conf.high, digits),
    clears_zero = ifelse(sign(t$conf.low) == sign(t$conf.high), "yes", ""),
    stringsAsFactors = FALSE
  )
}

# ----------------------------------------------------------
# vc_tbl() -- the SRM variance decomposition, summarised with a 95%
# credible interval per component. This is the headline table of the
# assignment.
#   va  = sender (row) variance      -- some actors send more
#   vb  = receiver (column) variance -- some actors receive more
#   cab = sender-receiver covariance -- are big senders big receivers?
#   rho = reciprocity                -- correlation within a dyad
#   ve  = residual variance          -- what is left
# ----------------------------------------------------------
vc_tbl <- function(fit, digits = 3) {
  labels <- c(
    va  = "va  : sender (row) variance",
    cab = "cab : sender-receiver covariance",
    vb  = "vb  : receiver (col) variance",
    rho = "rho : reciprocity (dyadic corr.)",
    ve  = "ve  : residual variance"
  )
  s <- t(apply(fit$VC, 2, function(x)
    c(mean = mean(x), lo = quantile(x, .025), hi = quantile(x, .975))))
  data.frame(
    component   = labels[rownames(s)],
    estimate    = round(s[, 1], digits),
    lo          = round(s[, 2], digits),
    hi          = round(s[, 3], digits),
    clears_zero = ifelse(sign(s[, 2]) == sign(s[, 3]), "yes", ""),
    row.names = NULL, stringsAsFactors = FALSE
  )
}

# ----------------------------------------------------------
# ppsd() -- goodness of fit as a single number per statistic: how many
# posterior-predictive standard deviations the OBSERVED network sits
# from the center of the networks the model simulates. Small (< ~2) is
# good; large means the model cannot reproduce that feature. Reads the
# same $GOF object gof_plot() draws, so the plot and the number agree.
# ----------------------------------------------------------
ppsd <- function(fit, digits = 2) {
  G <- fit$GOF; obs <- G[1, ]; sim <- G[-1, , drop = FALSE]
  round(vapply(colnames(G),
               function(s) as.numeric(abs(obs[s] - mean(sim[, s])) / sd(sim[, s])),
               numeric(1)), digits)
}

# ----------------------------------------------------------
# compare_fits() -- two fits side by side. The comparison we make on
# every modeling day: what did adding network structure do to each
# point estimate, and what did it do to the WIDTH of each interval?
# width_ratio > 1 means the second fit's interval is wider.
# ----------------------------------------------------------
compare_fits <- function(a, b, names = c("a", "b"), digits = 3) {
  ta <- lame::tidy(a); tb <- lame::tidy(b)
  stopifnot(identical(ta$term, tb$term))
  wa <- ta$conf.high - ta$conf.low
  wb <- tb$conf.high - tb$conf.low
  out <- data.frame(
    term        = ta$term,
    est_a       = round(ta$estimate, digits),
    est_b       = round(tb$estimate, digits),
    width_ratio = round(wb / wa, 2),
    moved       = ifelse(sign(ta$conf.low) == sign(ta$conf.high) &
                           sign(tb$conf.low) != sign(tb$conf.high), "lost sig",
                    ifelse(sign(ta$conf.low) != sign(ta$conf.high) &
                             sign(tb$conf.low) == sign(tb$conf.high), "gained sig", "")),
    stringsAsFactors = FALSE
  )
  names(out)[2:3] <- paste0("est_", names)
  out
}
