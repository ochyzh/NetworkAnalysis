# HW 3 (Social Relations Model) — grading rubric

Consistent with the syllabus's per-assignment scale:

> **0** — no submission
> **1** — does not demonstrate comprehension of the methodology
> **2** — adequate comprehension demonstrated
> **3** — excellent comprehension demonstrated

A student earns a grade for the assignment as a whole, not point-by-point.
The descriptors below say what each grade looks like on *this* assignment
so grading is consistent across the 37-student, 26-remote cohort. The
required part (Q1–Q5) is the basis for a 2; the stretch and the sharper
reading is what lifts a 2 to a 3.

---

## 3 — excellent comprehension

Everything runs from a clean session, and the interpretation is precise:

- **Variance decomposition (Q2).** Reads all five components correctly
  *and* separates the largest *variance* (`ve`) from the dominant
  *network dependence* (reciprocity, `rho ≈ 0.59`). Translates each
  parameter into a sentence about students and ratings, and notices that
  `cab > 0` means warm raters tend also to be popular.
- **Covariates (Q3).** States which intervals clear zero, and reads
  `male_row` vs `male_col` as a **sender/receiver asymmetry** (gender
  shows up in being *chosen*, not in *choosing*) — explicitly noting an
  undirected model could not separate the two. Does not oversell the
  non-credible coefficients (`smoker`, `same_smoker`).
- **Fit (Q4).** Identifies `trans.dep`/`cycle.dep` as the misfit and
  explains **why an additive model must miss transitivity** (a row effect
  is one number for all of an actor's partners; triangles need a third
  actor), connecting it forward to the latent-space/factor models.
- **SRM vs OLS (Q5).** Ties the nodal-interval widening to **effective
  sample size** (≈32 actors, not 992 dyads), keeps the width story
  separate from the point-estimate story, and resists the "SRM just
  inflates SEs" shorthand.
- **Stretch.** At least one stretch done correctly, with a real
  conclusion (e.g. S1: `dyad.dep` breaks yet coefficients barely move,
  *and* an explanation of why; or S2: `trans.dep` drops sharply under
  `R = 2` with a sentence on what the latent coordinates do).

## 2 — adequate comprehension

The required tasks are attempted and mostly correct, but the reading
stays at the surface. Typical of a 2:

- Reports the five variance components and the coefficient table
  correctly, but only as numbers ("`va` is 0.13") without the substantive
  translation, or treats `ve` as "the answer" without recognizing
  reciprocity as the dominant structure.
- Notes the nodal intervals widened but attributes it vaguely to "network
  dependence" rather than effective sample size; misses that a point
  estimate (`same_program`) also moved.
- Identifies the GOF misfit but calls it a convergence/tuning problem
  rather than a structural limit of the additive model.
- Little or no stretch, or a stretch that runs but is not interpreted.

## 1 — does not demonstrate comprehension

Submitted, but the methodology is not understood. Examples:

- Interprets the SRM as if the rows were independent, or reads a
  non-credible coefficient (e.g. `smoker`) as a real effect.
- Confuses sender and receiver effects, or reciprocity with the
  sender–receiver covariance.
- Reports GOF as "good fit" without noticing the transitivity failure, or
  concludes the SRM "made the SEs worse" as if that were a flaw.
- Code does not run / results are inconsistent with the model.

## 0 — no submission

---

## Grading notes / common issues

- **`gof_plot()` must be called with no `statistics=` argument.** This
  build of lame (1.3.1) throws a hard error on
  `gof_plot(fit, statistics = ...)`; the correct call is `gof_plot(fit)`,
  which draws all five statistics. A student who hit that error and
  worked around it correctly should not be penalized; one who reports the
  error as a result should be nudged, not docked.
- **`R = 0` fits have no `U`/`V`.** For Q2, actor effects come from
  `fit$APM` / `fit$BPM` (named by actor), **not** `rownames(fit$U)`.
  Students who reach for `U` on the pure SRM will get `NULL`.
- **Stretch S2 (`R > 0`):** reconstruct multiplicative effects with
  `tcrossprod(fit$U, fit$V)`; `fit$UVPM` is unreliable for `R > 0` in this
  build. The GOF numbers the task asks for are unaffected.
- **The point estimates barely move in S1 here** (unlike the trade
  example in lecture). That is correct for this dataset and is itself a
  strong observation — reward the student who explains *why* (reciprocity
  is a dyadic error structure, so it always wrecks `dyad.dep`, but only
  distorts coefficients when the dyadic covariates correlate with the
  reciprocated structure, which they don't here).
- **Reproducibility.** Everything is seeded (`6886`) and cached; a correct
  submission reproduces the key's numbers exactly. Divergent numbers
  usually mean the actor ordering was not aligned (`Y` vs `Xn`/`Xd`) or
  the fit was run unseeded.

A worked solution with the target numbers is in
`hw3_srm_solutions.qmd` / `.html`.
