# HW 3 — the Social Relations Model

Due on the **SRM day (Session 2)**. Students apply the SRM to a directed
network and interpret the sender/receiver/dyadic variance decomposition
and the covariate effects, using `lame` 1.3.1. Budget 1–3 hours; graded
0–3.

This folder is **self-contained** — a student can unzip just this folder
and render either document; nothing reaches outside it.

## Contents

| file | what it is |
|---|---|
| `hw3_srm.qmd` | the assignment students receive and complete |
| `hw3_srm_solutions.qmd` | instructor solution key (runs; every number is live) |
| `rubric.md` | the 0–3 grading rubric with per-task descriptors |
| `data/dutch_friends.rda` | the data: `Y` (32×32 ratings), `nodes` (32×4 attributes) |
| `_hw3_helpers.R` | `cache_fit`, `ess`, `coef_tbl`, `vc_tbl`, `ppsd`, `compare_fits` |
| `hw3.css` | local styling |
| `cache/` | precomputed fits so both documents render in seconds |

## The dataset

Wave 3 of the round-robin friendship ratings of 32 Dutch university
freshmen (van de Bunt, van Duijn & Snijders 1999), re-saved here with no
`amen` dependency. Ratings run −1 (troubled) to 4 (best friends);
attributes are `male`, `smoker`, `program`. A directed, valued, neutral
(non-IR) network with genuine reciprocity and homophily — the exact
round-robin structure the SRM was built for. It is **not** the trade
network used in the SRM-day walkthrough, so this is a fresh application.

## Render

```bash
quarto render hw3_srm_solutions.qmd   # populates cache/ on first run
quarto render hw3_srm.qmd             # reuses the cache
```

Fits are seeded (`6886`) and cached via `cache_fit()`; the first render
pays for them (~1–2 min), every render after is instant.
