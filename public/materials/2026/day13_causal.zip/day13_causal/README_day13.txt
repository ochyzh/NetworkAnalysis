DAY 13: CAUSAL INFERENCE ON NETWORKS
====================================

Open day13_causal.html to read the complete walkthrough without running R. Open day13_causal_teaching_deck.html for the presentation.

The presenter materials are split by purpose. `day13_notes.txt` is the live slide-by-slide script, `day13_notes_phone.pdf` is the phone-sized version of that script, and `day13_briefing.txt` contains the longer preparation material, technical explanations, likely questions, and cautions.

The source files are day13_causal.qmd and day13_causal_teaching_deck.qmd. To render them, keep every file in this folder together and install the CRAN packages ggplot2, lmtest, and sandwich. The walkthrough uses relative paths and does not require a package cache.

The two included data files support the Nickerson household-mobilization calculation and the Ichino-Schündeln election-observer replication. DATA_SOURCES.txt records their provenance and terms. The Paluck and Egami figures reconstruct published aggregate estimates because the relevant student-level microdata are restricted.

The rendered walkthrough and deck are included so students can read the materials and inspect every result without rerunning the analysis.
