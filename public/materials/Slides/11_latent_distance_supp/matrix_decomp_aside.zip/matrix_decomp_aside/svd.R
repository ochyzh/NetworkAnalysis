#################
rm(list=ls())
#################

#################
library(ggplot2)
library(ggrepel)
library(patchwork)
#################

#################
mat = matrix(c(
    1, 1, 1, 0, 0,
    3, 3, 3, 0, 0,
    4, 4, 4, 0, 0,
    5, 5, 5, 0, 0, 
    0, 2, 0, 4, 4, 
    0, 0, 0, 5, 5, 2
    0, 1, 0, 2, 2
), ncol=5, byrow=TRUE)
rownames(mat) = c('Mike', 'Cindy', 'Juan', 'Emily', 'Cassy', 'Juan', 'Max')
colnames(mat) = c('Matrix', 'Alien', 'Serenity', 'Casablanca', 'Amelie')
#################

#################
# user side
mds_pos_user = cmdscale(dist(mat), eig=TRUE, k=2)

df_user = data.frame(mds_pos_user$points)
names(df_user) = c('x', 'y')
df_user$viewer = rownames(df_user)
rownames(df_user) = NULL

viz_user_mds = ggplot(df_user, aes(x=x, y=y, label=viewer)) +
    geom_point() +
    geom_text_repel() +
    labs(title='User side MDS') +
    theme_minimal()

# movie side
mds_pos_movie = cmdscale(dist(t(mat)), eig=TRUE, k=2)

df_movie = data.frame(mds_pos_movie$points)
names(df_movie) = c('x', 'y')
df_movie$movie = rownames(df_movie)
rownames(df_movie) = NULL

viz_movie_mds = ggplot(df_movie, aes(x=x, y=y, label=movie)) +
    geom_point() +
    geom_text_repel() +
    labs(title='Movie side MDS') +
    theme_minimal()

#
viz_user_mds + viz_movie_mds
#################

#################
svd_mod = svd(mat)

#
U = svd_mod$u[,1:2]
D = diag(svd_mod$d)[1:2]
V = svd_mod$v[,1:2]

# 
df_u = data.frame(U)
df_u$viewer = rownames(mat)

# 
df_v = data.frame(V)
df_v$movie = colnames(mat)

#
viz_user_svd = ggplot(
    df_u, aes(x=X1, y=X2, label=viewer)) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "gray") +
    geom_vline(xintercept = 0, linetype = "dashed", color = "gray") +
    geom_segment(aes(x = 0, y = 0, xend = X1, yend = X2), 
                 arrow = arrow(length = unit(0.2, "cm"))) +
    geom_point() +
    geom_text_repel() +
    labs(title='User side SVD', x='', y='') +
    theme_minimal() +
    xlim(-1, 1) +
    ylim(-1, 1)

#
viz_movie_svd = ggplot(
    df_v, aes(x=X1, y=X2, label=movie)) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "gray") +
    geom_vline(xintercept = 0, linetype = "dashed", color = "gray") +
    geom_segment(aes(x = 0, y = 0, xend = X1, yend = X2), 
                 arrow = arrow(length = unit(0.2, "cm"))) +
    geom_point() +
    geom_text_repel() +
    labs(title='Movie side SVD', x='', y='') +
    theme_minimal() +
    xlim(-1, 1) +
    ylim(-1, 1)

#
viz_user_svd + viz_movie_svd