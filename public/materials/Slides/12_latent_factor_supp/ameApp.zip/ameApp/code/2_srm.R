####
# path setup
require(here)
pth = paste0(here::here(), '/')
dpth = paste0(pth, 'data/')
rpth = paste0(pth, 'results/')
####

####
# packages (all available on cran)
packs = c(
  'amen', # 1.4.4
  'ggplot2', # 3.34
  'tidyr', # 1.1.3
  'reshape2', # 1.4.4
  'gridExtra' # 2.3
)

# load packages
shh = lapply(packs, library, character.only=TRUE)

# helper functions
source(paste0(pth, 'code/helpers.R'))
source(paste0(pth, 'code/ameHelpers.R'))
####

####
# for better or worse, amen is very different in the
# input it expects and how it structures output

# lets load trade the directed dyadic data version
# of the trade data and prep it for ame
load(paste0(dpth, 'ameCrossSec.rda'))

# we're starting with a typical df object
head(trade)
####

####
# lets start with the dv
# for cross-sectional network the amen
# package expects a n x n matrix for the DV

# in the other script I showed
# how to do it lazily with a for
# loop and a preallocated object,
# this time lets use the acast
# function from reshape2
# (note i'm avoiding tidyr because
# it outputs a data.frame/tibble)
yMat = acast(
	data=trade,
	formula=Var1 ~ Var2,
  value.var='trade' )

# now lets construct our dyadic variables
# for cross-sectional networks the amen
# package expects a n x n x pd array for
# the dyadic covariates, where pd
# refers to the number of dyadic variables

# to construct this we'll first reshape our
# data, so that each of the dyadic variables
# is going down a column
ids = c('Var1', 'Var2')
dyadVars = c('conflicts', 'distance', 'shared_igos')
dyadVarLong = melt(
  trade[,c(ids, dyadVars)], id=c('Var1', 'Var2'))

# now lets turn them into an array using
# acast again
dyadArr = acast(
  data=dyadVarLong,
  formula=Var1~Var2~variable,
  value.var='value' )

# last lets prep our nodal variables
# for cross-sectional networks the amen
# package expects a n x pr/c matrix for the
# the nodal variables
# ame also allows you to input sender and
# receiver specific nodal variables
nVars = c('pop','gdp','polity')
sendVars = paste0(nVars, '1')
recVars = paste0(nVars, '2')
sendLong = unique(trade[,c('Var1', sendVars)])
sMat = data.matrix(sendLong[,-1])
rownames(sMat) = sendLong$Var1

recLong = unique(trade[,c('Var2', recVars)])
rMat = data.matrix(recLong[,-1])
rownames(rMat) = recLong$Var2

# now lets just make sure that the countries
# show up in the same order for each of our objects
# we'll use the ordering of actors in yMat as a guide
actors = rownames(yMat)

# apply this ordering scheme to dyadArr
dyadArr = dyadArr[actors,actors,]

# and to the matrices for sender and
# receiver covariates
sMat = sMat[actors,]
rMat = rMat[actors,]

# lets save these objects because
# we'll be using them in later scripts
save(
  yMat,
  dyadArr,
  sMat,
  rMat,
  file=paste0(dpth, 'ameCrossSec_v2.rda')
)
####

####
# great we're all set with the data

# now lets start simple and get a feel for ame
# we'll start by turning off all the net
# related parameters and run what is essentially
# a simple bayesian linear regression
# should not take more than 30 secs
if(!file.exists(paste0(rpth, 'fitNoNet.rda'))){
  fitNoNet = ame(
    Y=yMat,
    Xdyad=dyadArr,
    Xrow=sMat,
    Xcol=rMat,
    family='nrm',
    rvar=FALSE,
    cvar=FALSE,
    dcor=FALSE,
    R=0,
    intercept=TRUE,
    symmetric=FALSE,
    seed=6886,
    nscan=10000,
    burn=5000,
    odens=10,
    plot=FALSE,
    print=FALSE,
    gof=TRUE
  )
  save(fitNoNet, file=paste0(rpth, 'fitNoNet.rda'))
} else {
  load(paste0(rpth, 'fitNoNet.rda')) }
####

####
# ame output
names(fitNoNet)

# BETA
# posterior samples for reg coefs
head(fitNoNet$BETA)

# VC
# posterior samples for vc params
head(fitNoNet$VC)

# YPM
# posterior mean of Y (predicted values)
dim(fitNoNet$YPM)
fitNoNet$YPM[1:5,1:5]

# GOF
# goodness of fit stats
# first row represents observed
# remaining rows represent gof
# stat for every predicted network
head(fitNoNet$GOF)
####

####
# first steps after running an ame model
# check if the model converged
# construct trace plots for beta estimates
beta = fitNoNet$BETA

# reorg data
beta = data.frame(beta)
beta$iter = 1:nrow(beta)
betaLong = melt(beta, id='iter')

# viz
ggplot(betaLong, aes(x=iter, y=value, group=variable)) +
  geom_line() +
  facet_wrap(~variable, scales='free_y', ncol=1) +
  theme_bw() +
  theme(
    axis.ticks=element_blank(),
    panel.border=element_blank()
  )

# helper function from me in the
# ameHelpers file that does something similar but
# with a bit more info
paramPlot(fitNoNet$BETA[,1:5])
paramPlot(fitNoNet$BETA[,6:10])
####

####
# next step after you've ensured
# the trace plots look okay is to check gof
# in our case keep in mind that we are at
# this point just running a bayesian
# linear regression
head(fitNoNet$GOF)

# we'll focus on sd.rowmean, sd.colmean
# dyad.dep, and trans.dep for this workshop
gof = fitNoNet$GOF[,-4]
head(gof)
actualVals = fitNoNet$GOF[1,]
gof = gof[-1,]

# reorg for plotting
gof = data.frame(gof)
gof$iter = 1:nrow(gof)
gofLong = melt(gof, id='iter')

# add in a column for the actual values
gofLong$actual = NA
gStats = unique(char(gofLong$variable))
for(g in gStats){
  gofLong$actual[gofLong$variable==g] = actualVals[g] }

# now lets plot
ggplot(gofLong, aes(x=value)) +
  geom_histogram() +
  geom_vline(aes(xintercept=actual), color='red') +
  facet_wrap(~variable, scales='free_y') +
  theme_bw() +
  theme(
    axis.ticks=element_blank(),
    panel.border=element_blank()
  )

# again a helper function from ameHelpers
# just need to make sure to remove the cycles calc
gofPlot(
  fitNoNet$GOF[,-4],
  symmetric=FALSE)
####

####
# okay, so the networks that we simulated from our
# model are not doing a good job in capturing the
# gof stats that we're targeting, lets run
# a model with the srm parameters added in
# now lets add in the srm parameters
if(!file.exists(paste0(rpth, 'fitSRM.rda'))){
  fitSRM = ame(
    Y=yMat,
    Xdyad=dyadArr,
    Xrow=sMat,
    Xcol=rMat,
    family='nrm',
    rvar=TRUE,
    cvar=TRUE,
    dcor=TRUE,
    R=0,
    intercept=TRUE,
    symmetric=FALSE,
    seed=6886,
    nscan=10000,
    burn=5000,
    odens=10,
    plot=FALSE,
    print=FALSE,
    gof=TRUE
  )
  save(fitSRM, file=paste0(rpth, 'fitSRM.rda'))
} else {
  load(paste0(rpth, 'fitSRM.rda')) }
####

####
# repeat checks, first check for
# convergence
paramPlot(fitSRM$BETA[,1:5])
paramPlot(fitSRM$BETA[,6:10])

# now lets see how we're doing wrt
# to the gof stats in the observed
# network
gofPlot(fitSRM$GOF[,-4], FALSE)
head(fitSRM$GOF)
####

####
# great, our model seems to be performing
# better on the gofStats that we've discussed so far
# before dealing with where we are still off lets
# talk about the other output that this model
# generated for us

# as a reminder
names(fitSRM)

# first lets check the posterior samples for
# the vc params again
head(fitSRM$VC)

# we can use the paramPlot function to summarize
# these results
paramPlot(fitSRM$VC)

# and there's more, we also now have
# sender and receiver random effects from the model
# as well
head(fitSRM$APM)
head(fitSRM$BPM)

# we can visualize these as well
muEff = fitSRM$APM
muDf = data.frame(mu=muEff)
muDf$id = rownames(muDf)
muDf$id = factor(muDf$id, levels=muDf$id[order(muDf$mu)])
muDf$ymax = with(muDf, ifelse(mu>=0,mu,0))
muDf$ymin = with(muDf, ifelse(mu<0,mu,0))
ggplot(muDf, aes(x=id, y=mu)) +
  geom_point() +
  geom_linerange(aes(ymax=ymax,ymin=ymin)) +
  xlab('') + ylab('Sender Effects') +
  theme(
    axis.ticks=element_blank(),
    axis.text.x=element_text(angle=45, hjust=1, size=4)
  )

# there's a function in ameHelpers that we can
# use to construct this viz as well called
# abPlot, it's pretty simple
abPlot(fitSRM$APM, 'Sender Effects')

# but now lets put all the pieces of
# that we estimated from the srm
# together
source(paste0(pth, 'code/ameHelpers.R'))
grid.arrange(
  paramPlot(fitSRM$VC),
  arrangeGrob(
    abPlot(fitSRM$APM, 'Sender Effects'),
    abPlot(fitSRM$BPM, 'Receiver EFfects')
  ), ncol = 2)
####

####
# and of course, the actual regression coef
# results!

# there's a great function in the amen package
# to quickly get a summary of parameter estimates
summary(fitSRM)

# we can compare this to the model where we
# did not inlcude the srm parameters
summary(fitNoNet)

# you can also easily calculate these from
# the beta matrix in the output as well
# with a more bayesian flavor
summChain = function(x){
  mu = mean(x)
  qt90s = quantile(x, probs=c(0.05, 0.95))
  qt95s = quantile(x, probs=c(0.025, 0.975))
  out = c(
    lo95 = qt95s[1],
    lo90 = qt90s[1],
    mu = mean(x),
    hi95 = qt95s[2],
    hi90 = qt90s[2] )

  #
  return(out) }

#
round(t(apply(fitSRM$BETA, 2, summChain)), 2)
round(t(apply(fitNoNet$BETA, 2, summChain)), 2)

# and then proceed to generate tables
# via your favorite .tex table generator
# or hopefully via a viz instead
####
