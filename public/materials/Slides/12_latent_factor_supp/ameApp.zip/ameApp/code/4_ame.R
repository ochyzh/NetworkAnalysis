####
# path setup
require(here)
pth = paste0(here::here(), '/')
dpth = paste0(pth, 'data/')
rpth = paste0(pth, 'results/')
####

####
# packages (all available on cran)
packs = c(
  'amen', # 1.4.4
  'ggplot2', # 3.34
  'tidyr', # 1.1.3
  'reshape2', # 1.4.4
  'gridExtra', # 2.3
  'ggrepel'
)

# load packages
shh = lapply(packs, library, character.only=TRUE)

# helper functions
source(paste0(pth, 'code/helpers.R'))
source(paste0(pth, 'code/ameHelpers.R'))
####

####
# okay lets put srm and lfm together
# to get ame for our example
# one more time lets just pretend as though we're running
# a model from scratch, ie starting with directed
# dyadic data
load(paste0(dpth, 'ameCrossSec.rda'))

# process y
yMat = acast(
	data=trade,
	formula=Var1 ~ Var2,
  value.var='trade' )

# process xd
ids = c('Var1', 'Var2')
dyadVars = c('conflicts', 'distance', 'shared_igos')
dyadVarLong = melt(
  trade[,c(ids, dyadVars)], id=c('Var1', 'Var2'))
dyadArr = acast(
  data=dyadVarLong,
  formula=Var1~Var2~variable,
  value.var='value' )

# process nodal variables
nVars = c('pop','gdp','polity')
sendVars = paste0(nVars, '1')
recVars = paste0(nVars, '2')
sendLong = unique(trade[,c('Var1', sendVars)])
sMat = data.matrix(sendLong[,-1])
rownames(sMat) = sendLong$Var1

recLong = unique(trade[,c('Var2', recVars)])
rMat = data.matrix(recLong[,-1])
rownames(rMat) = recLong$Var2

# run ame
if(!file.exists(paste0(rpth, 'fitAME.rda'))){
  fitAME = ame(
    Y=yMat,
    Xdyad=dyadArr,
    Xrow=sMat,
    Xcol=rMat,
    symmetric=FALSE,
    intercept=TRUE,
    family='nrm',
    rvar=TRUE,
    cvar=TRUE,
    dcor=TRUE,
    R=2,
    seed=6886,
    nscan=10000,
    burn=5000,
    odens=10,
    plot=FALSE,
    print=FALSE,
    gof=TRUE
  )
save(fitAME, file=paste0(rpth, 'fitAME.rda'))
} else { load(paste0(rpth, 'fitAME.rda')) }
####

####
# lets do our checks
# first trace plot
paramPlot(fitAME$BETA[,1:5])
paramPlot(fitAME$BETA[,6:10])

# gof check
gofPlot(fitAME$GOF[,-4], FALSE)

# srm check
grid.arrange(
  paramPlot(fitAME$VC),
  arrangeGrob(
    abPlot(fitAME$APM, 'Sender Effects'),
    abPlot(fitAME$BPM, 'Receiver EFfects')
  ), ncol = 2)

# examine the regression coefficients
round(t(apply(fitAME$BETA, 2, summChain)), 2)
####

####
# and there is one more thing ...
# rings of fire ...
circplot(Y=yMat, U=fitAME$U, V=fitAME$V)

# also a ggplot version that is in the
ggCirc(
  Y=yMat, U=fitAME$U, V=fitAME$V ) +
  scale_color_manual(values=rep(ccols,2)) +
  theme_minimal() +
  theme(
    legend.position='none',
    axis.text=element_blank(),
    axis.title=element_blank()
  )

# add a splash of color
load(paste0(dpth, 'tradeMapCols.rda'))
ggCirc(
  Y=yMat, U=fitAME$U, V=fitAME$V,
  color=names(rep(ccols,2)) ) +
  scale_color_manual(values=rep(ccols,2)) +
  theme_minimal() +
  theme(
    legend.position='none',
    axis.text=element_blank(),
    axis.title=element_blank()
  )
####
