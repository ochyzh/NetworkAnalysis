####################################################
#' Plot parameter results from MCMC
#'
#' @param mcmcData matrix of values from MCMC
#' @return Trace plot and density distribution of
#' estimated parameters
#' @author Shahryar Minhas
#' @export
paramPlot <- function(mcmcData){

  # libs
  suppressMessages(library(ggplot2))
  suppressMessages(require(plyr))
  suppressMessages(require(reshape2))

  colnames(mcmcData) <- names(data.frame(mcmcData))
  mcmcMelt <- reshape2::melt(mcmcData)
  names(mcmcMelt) <- c('Var1', 'Var2', 'value')
  mcmcMelt$mu <- with(mcmcMelt, ave(value, Var2, FUN=mean))
  mcmcMelt$median <- with(mcmcMelt, ave(value, Var2, FUN=median))
  qts <- c(lo95=0.025,lo90=0.05,hi90=0.95,hi95=0.975)
  for(i in 1:length(qts)){
    mcmcMelt$tmp <- with(mcmcMelt, ave(value, Var2, FUN=function(x){quantile(x,probs=qts[i])}))
    names(mcmcMelt)[ncol(mcmcMelt)] <- names(qts)[i]
  }

  ggTrace <- ggplot2::ggplot(mcmcMelt, aes(x=Var1, y=value)) +
    geom_hline(aes(yintercept=mu), color='red') +
    geom_ribbon(aes(ymin=lo90,ymax=hi90), alpha=.5, fill='grey40') +
    geom_ribbon(aes(ymin=lo95,ymax=hi95), alpha=.3, fill='grey40') +
    geom_line(lwd=.6) +
    xlab('Post-Burn Iteration') +
    ylab('Parameter Value') +
    facet_wrap(~Var2, ncol=1, scales='free_y') +
    theme_bw() +
    theme(
      panel.border=element_blank(),
      axis.ticks=element_blank()
      )

  ggMu <- plyr::ddply(mcmcMelt, .(Var2), summarise, mu=mean(value))
  ggDens <- plyr::ddply(mcmcMelt,.(Var2),.fun = function(x){
    tmp <- density(x$value) ; x1 <- tmp$x; y1 <- tmp$y
    q90 <- x1 >= quantile(x$value,0.05) & x1 <= quantile(x$value,0.95)
    q95 <- x1 >= quantile(x$value,0.025) & x1 <= quantile(x$value,0.975)
    data.frame(x=x1,y=y1,q90=q90,q95=q95) })

  ggDist <- ggplot2::ggplot(ggDens, aes(x=x)) +
    facet_wrap(~ Var2, scales='free', ncol=1) +
    geom_vline(data=ggMu, aes(xintercept=mu), linetype='solid', size=1, color='red') +
    geom_line(aes(y=y), color='grey40') + ylab('') +
    xlab('Parameter Value') +
    geom_ribbon(data=subset(ggDens, q90), aes(ymax=y),ymin=0, alpha=.7, fill='grey40') +
    geom_ribbon(data=subset(ggDens, q95), aes(ymax=y),ymin=0, alpha=.5, fill='grey40') +
    theme_bw() +
    theme(
      panel.border=element_blank(),
      axis.ticks=element_blank(),
      axis.text.y=element_blank()
    )

  return( gridExtra::grid.arrange(ggTrace, ggDist, ncol=2) )

}
####################################################

####################################################
#' Plot results of goodness of fit tests
#'
#' @param GOF matrix of GOF values from ame_repL
#' @param symmetric logical: Is the sociomatrix symmetric by design?
#' @return Plot for goodness of fit statistics
#' @author Shahryar Minhas
#' @export
gofPlot <- function(GOF, symmetric){

	# libs
	suppressMessages(library(ggplot2))
	suppressMessages(require(plyr))
	suppressMessages(require(reshape2))

	# org data
	actGOF <- GOF[1,]
	meltGOF <- reshape2::melt(GOF[-1,], stringsAsFactors=FALSE)
	ggMu <- plyr::ddply(meltGOF, .(Var2), summarise, mu=mean(value))
	ggMu$actual <- actGOF[match(ggMu$Var2,names(actGOF))]
	ggDens <- plyr::ddply(meltGOF,.(Var2),.fun = function(x){
	  tmp <- density(x$value) ; x1 <- tmp$x; y1 <- tmp$y
	  q90 <- x1 >= quantile(x$value,0.05) & x1 <= quantile(x$value,0.95)
	  q95 <- x1 >= quantile(x$value,0.025) & x1 <= quantile(x$value,0.975)
	  data.frame(x=x1,y=y1,q90=q90,q95=q95) })

	## code to only extend line segments to top of density dist
	# ggMu$yEnd=Inf
	# for(v in as.character(ggMu$Var2)){
	#   densSlice <- ggDens[which(ggDens$Var2==v),]
	#   diff <- abs(densSlice$x-ggMu$mu[ggMu$Var2==v])
	#   ggMu$yEnd[ggMu$Var2==v] <- densSlice$y[which(diff==min(diff))]
	# }

	# ggMu$yEndForAct=Inf
	# for(v in as.character(ggMu$Var2)){
	#   densSlice <- ggDens[which(ggDens$Var2==v),]
	#   diff <- abs(densSlice$x-ggMu$actual[ggMu$Var2==v])
	#   ggMu$yEndForAct[ggMu$Var2==v] <- densSlice$y[which(diff==min(diff))]
	# }

	# cleanup based on conditions
	ggData <- list(ggMu=ggMu,ggDens=ggDens,meltGOF=meltGOF)
	ggData <- lapply(ggData,function(x){x$Var2<-as.character(x$Var2);return(x)})
	if(symmetric){
		# remove dyadic dep calculation if symmetric
		ggData<-lapply(ggData,function(x){x=x[which(x$Var2!='dyad.dep'),];return(x)})
		# adjust node variation plot
		ggData<-lapply(ggData,function(x){
			x <- x[which(x$Var2!='sd.colmean'),]
			x$Var2[which(x$Var2=='sd.rowmean')] <- 'sd.nodemean'
			return(x) })
	}

	# cleanup
	ggData<-lapply(ggData,function(x){
		x$Var2<-factor(x$Var2,
			levels=c('sd.rowmean','sd.colmean','sd.nodemean','dyad.dep','trans.dep'))
		return(x) })
	ggDens<-ggData$ggDens;ggMu<-ggData$ggMu;meltGOF<-ggData$meltGOF;rm(ggData)

	# plot
	ggGOF <- ggplot2::ggplot(ggDens, aes(x=x)) +
	  geom_histogram(data=meltGOF, aes(x=value, y=..density..),
	  	fill='grey95', color='black', lwd=1.25) +
	  geom_line(aes(y=y), color='black', lwd=1) +
	  geom_ribbon(data=subset(ggDens, q90), aes(ymax=y),ymin=0, alpha=.6, fill='grey20') +
	  geom_ribbon(data=subset(ggDens, q95), aes(ymax=y),ymin=0, alpha=.5, fill='grey20') +
	  geom_vline(data=ggMu, aes(xintercept=mu),
	             linetype='solid', size=1, color='red') +
	  geom_vline(data=ggMu, aes(xintercept=actual),
	             linetype='solid', size=1, color='blue') +
	  # geom_segment(data=ggMu, aes(x=mu,xend=mu,y=0,yend=yEnd),
	  #              linetype='solid', color='red', size=2) +
	  # geom_segment(data=ggMu, aes(x=actual,xend=actual,y=0,yend=yEndForAct),
	  #            linetype='solid', size=2, color='blue') +
	  facet_wrap(~ Var2, scales='free') + ylab('') +
	  xlab('Parameter Value\nBlue line denotes actual value and red denotes mean of simulated.\nShaded interval represents 90 and 95 percent credible intervals.') +
	  theme_bw() +
	  theme(
	    panel.border=element_blank(),
	    axis.ticks=element_blank(),
	    axis.text.y=element_blank()
	  )

  return( ggGOF )
}
####################################################

####################################################
# fn to do a quick plot of send/rec
# random effects
abPlot=function(muEff, ylabel='Sender Additive Effects'){
  muDf = data.frame(mu=muEff)
  muDf$id = rownames(muDf)
  muDf$id = factor(muDf$id, levels=muDf$id[order(muDf$mu)])
  muDf$ymax = with(muDf, ifelse(mu>=0,mu,0))
  muDf$ymin = with(muDf, ifelse(mu<0,mu,0))
  gg = ggplot(muDf, aes(x=id, y=mu)) +
    geom_point() +
    geom_linerange(aes(ymax=ymax,ymin=ymin)) +
    xlab('') + ylab(ylabel) +
    theme(
      axis.ticks=element_blank(),
      axis.text.x=element_text(angle=45)
    )
  return(gg)
}
####################################################

####################################################
# fn to do a quick plot of mult effect positions
ggCirc = function(
  Y, U=NULL, V=NULL, row.names=rownames(Y), col.names=colnames(Y),
  vscale=.6, prange=c(2,5), lcol='gray85', ltype='dotted', lsize=.5,
  force=2, maxIter = 3e3,
  showActLinks=FALSE, geomLabel=TRUE, geomText=FALSE, geomPoint=TRUE, ...
){

  #
  library(ggrepel)
  library(ggplot2)

  if (is.null(U)) {
    a <- rowMeans(Y, na.rm = TRUE)
    b <- colMeans(Y, na.rm = TRUE)
    Y0 <- Y
    Y0[is.na(Y)] <- (outer(a, b, "+"))[is.na(Y)]
    Y0 <- Y0 - mean(Y0)
    if (!all(Y == t(Y), na.rm = TRUE)) {
      sY <- svd(Y0)
      u <- sY$u[, 1:2]
      v <- sY$v[, 1:2]
      mu <- sqrt(apply(u^2, 1, sum))
      mv <- sqrt(apply(v^2, 1, sum))
      u <- diag(1/mu) %*% u
      v <- diag(1/mv) %*% v * vscale
    }
    if (all(Y == t(Y), na.rm = TRUE)) {
      eY <- eigen(Y0)
      bv <- which(abs(eY$val) >= sort(abs(eY$val), decreasing = TRUE)[2])[1:2]
      u <- eY$vec[, bv]
      mu <- sqrt(apply(u^2, 1, sum))
      u <- diag(1/mu) %*% u
      mv <- mu
      v <- u
    }
  }
  if (!is.null(U)) {
    if (is.null(V)) {
      V <- U
      vscale <- 1
    }
    mu <- sqrt(apply(U^2, 1, sum))
    mv <- sqrt(apply(V^2, 1, sum))
    u <- diag(1/mu) %*% U
    v <- diag(1/mv) %*% V * vscale
  }

  rsum <- apply(abs(Y), 1, sum, na.rm = TRUE)
  csum <- apply(abs(Y), 2, sum, na.rm = TRUE)
  links <- which(Y != 0, arr.ind = TRUE)

  # org df for gg
  uG = data.frame(u*1.2)
  uG$actor = rownames(Y)
  uG$tPch = 0 ; uG$tPch[rsum>0] = (mu[rsum>0])^3
  uG = uG[uG$tPch>0,]
  uG$tPch = uG$tPch

  # add v if supplied
  if(!is.null(V)){
    vG = data.frame(v*1.2)
    vG$actor = rownames(Y)
    vG$tPch = 0 ; vG$tPch[csum>0] = (mv[csum>0])^3
    vG = vG[vG$tPch>0,]
    vG$tPch = vG$tPch

    uG$eff = 'u' ; vG$eff = 'v'
    uG = rbind(uG, vG)
    ggCirc = ggplot(uG, aes(x=X1, y=X2,color=eff))
  }
  if(is.null(V)){
    ggCirc = ggplot(uG, aes(x=X1, y=X2))
  }

  # add segments
  if(showActLinks){
    for(i in 1:nrow(links)){
      ggCirc = ggCirc + geom_segment(
        x=u[links[i,1],1]*1.2, y=u[links[i,1],2]*1.2,
        xend=v[links[i,2],1]*1.2, yend=v[links[i,2],2]*1.2,
        color=lcol, linetype=ltype, size=lsize ) }
  }
  if(geomPoint){ ggCirc = ggCirc + geom_point(aes(...)) }
  if(geomLabel){ ggCirc = ggCirc + geom_label_repel(aes(label=actor, size=tPch, ...),
                                                    force=force, max.iter=maxIter) }
  if(geomText){ ggCirc = ggCirc + geom_text_repel(aes(label=actor, size=tPch, ...),
                                                  force=force, max.iter=maxIter) }
  ggCirc = ggCirc + scale_size(range=prange) +
    theme(
      legend.position='none',
      axis.ticks=element_blank(),
      axis.title=element_blank(),
      axis.text=element_blank(),
      panel.border=element_blank(),
      panel.grid=element_blank()
    )
  return(ggCirc)
}
####################################################
