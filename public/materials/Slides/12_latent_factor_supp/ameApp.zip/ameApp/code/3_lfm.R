####
# path setup
require(here)
pth = paste0(here::here(), '/')
dpth = paste0(pth, 'data/')
rpth = paste0(pth, 'results/')
####

####
# packages (all available on cran)
packs = c(
  'amen', # 1.4.4
  'ggplot2', # 3.34
  'tidyr', # 1.1.3
  'reshape2', # 1.4.4
  'gridExtra', # 2.3
  'doParallel',
  'foreach'
)

# load packages
shh = lapply(packs, library, character.only=TRUE)

# helper functions
source(paste0(pth, 'code/helpers.R'))
source(paste0(pth, 'code/ameHelpers.R'))
####

####
# before integrating the lfm into our practice
# example, lets walk through a controlled sim
# exercise so we can hopefully better understand
# what it's trying to do

# we'll play with a 50 actor network
n = 50

# lets generate some variables
set.seed(6886)
xw = matrix(rnorm(n*2),n,2)
X = tcrossprod(xw[,1])  ; W = tcrossprod(xw[,2])

# set up a model dgp
mu = -2 # intercept effect
beta = 1 # effect of observed covariate, X
gamma = 1 # effect of unobserved covariate, W
Z = mu + beta*X + gamma*W + matrix(rnorm(n*n),n,n)

# our dv here will be a binary
Y = 1*(Z>0)

# run AME model with R=1
if(!file.exists(paste0(rpth, 'fit1_lfm.rda'))){
  fit1 = ame(
    Y,X,
    family='bin', symmetric=FALSE,
    # dimension of multiplicative effect
    R=1,
    # turn off srm parameters
    rvar=FALSE,cvar=FALSE,dcor=FALSE,
  	print=FALSE,plot=FALSE )
  save(fit1, file=paste0(rpth, 'fit1_lfm.rda'))
} else { load(paste0(rpth, 'fit1_lfm.rda')) }
####

####
# lets take a look at the output
names(fit1)

# we've already discussed BETA, VC,
# APM, BPM (both not relevant here),
# now lets focus on U and V
head(fit1$U)
head(fit1$V)
dim(fit1$UVPM)

# what are we capturing in this uvpm matrix?
cor(c(W), c(fit1$UVPM), use='pairwise.complete.obs')
####

####
# is this a fluke?
# lets make a bunch of simulated networks
# run a bunch of ames, and get a distribution
# for the correlation between W and UVPM
simRun = function(seed, n, mu, beta, gamma){

  # set a seed
  set.seed(seed)

  # gen vars
	xw = matrix(rnorm(n*2),n,2)
	X = tcrossprod(xw[,1])  ; W = tcrossprod(xw[,2])

	# create DV
	Y = 1*(mu + beta*X + gamma*W + matrix(rnorm(n*n),n,n) >0)

	# run model
	fit1 = ame(Y,X,R=1,
    rvar=FALSE,cvar=FALSE,dcor=FALSE,family='bin',
		print=FALSE,plot=FALSE)

  # save relevant stat
  out = cor(c(W), c(fit1$UVPM), use='pairwise.complete.obs')
  return(out) }

# def not going to do this one at a time
# if you're going to use ame for real world applications
# it's helpful to be comfortable with parallelization
# i'll be using functions from doParallel and foreach to help
if(!file.exists(paste0(rpth, 'simCorrs.rda'))){
  cl = makeCluster(20)
  registerDoParallel(cl)
  simCorrs = foreach(imp = 1:30, .packages=c('amen')) %dopar% {
    simCorr = simRun(seed=imp, n=50, mu=-2, beta=1, gamma=1)
    return(simCorr) }
  stopCluster(cl)
  save(simCorrs, file=paste0(rpth, 'simCorrs.rda'))
} else { load(paste0(rpth, 'simCorrs.rda')) }

# lets pull out the results and plot
corrDF = data.frame(corr=unlist(simCorrs))
ggplot(corrDF, aes(x=corr)) +
  geom_density() +
  geom_vline(xintercept=mean(corrDF$corr))
####

####
# okay so how does this work in practice?
# lets go back to our example
load(paste0(dpth, 'ameCrossSec_v2.rda'))

# lets run lfm on our trade example
# to keep it simple for now we'll
# restrict the srm parameters
if(!file.exists(paste0(rpth, 'lfmFit2.rda'))){
  lfmFit2 = ame(
      Y=yMat,
      Xdyad=dyadArr,
      Xrow=sMat,
      Xcol=rMat,
      family='nrm',
      rvar=FALSE,
      cvar=FALSE,
      dcor=FALSE,
      R=2,
      intercept=TRUE,
      symmetric=FALSE,
      seed=6886,
      nscan=10000,
      burn=5000,
      odens=10,
      plot=FALSE,
      print=FALSE,
      gof=TRUE
  )
  save(lfmFit2, file=paste0(rpth, 'lfmFit2.rda'))
  } else { load(paste0(rpth, 'lfmFit2.rda')) }

# and lets check our gof plot
gofPlot(lfmFit2$GOF[,-4], FALSE)

# but why 2, why not 4, 8, 12?
# can we know a priori what to set?
# no ...
possKs = c(2, 4, 8, 12)
if(!file.exists(paste0(rpth, 'possKs.rda'))){
  cl = makeCluster(length(possKs))
  registerDoParallel(cl)
  gofOut = foreach(k = possKs, .packages=c('amen')) %dopar% {

    # run lfm with varying k
    lfmOut = ame(
        Y=yMat,
        Xdyad=dyadArr,
        Xrow=sMat,
        Xcol=rMat,
        family='nrm',
        rvar=FALSE,
        cvar=FALSE,
        dcor=FALSE,
        R=k,
        intercept=TRUE,
        symmetric=FALSE,
        seed=6886,
        nscan=10000,
        burn=5000,
        odens=10,
        plot=FALSE,
        print=FALSE,
        gof=TRUE )

    #
    return(lfmOut$GOF[,-4]) }
  stopCluster(cl)

  #
  save(gofOut, file=paste0(rpth, 'possKs.rda'))
  } else { load(paste0(rpth, 'possKs.rda')) }

# lets check our plots
lapply(gofOut, gofPlot, FALSE)
####

####
# out of sample performance
# there's a cost to adding on
# multiplicative effect
# dimensions, additionally
# do we only care about gof?
# shouldnt we also care about actual
# tie prediction as well?

# one of the most appealing features of a generative
# model is that it can handle missing data, we're
# going to utilize this fact to induce missingness
# in our network and conduct a k-fold cross-validation
# analysis on it

# lets generate a matrix with the same dims as yMat in
# which we assign observations to folds
folds = 5
set.seed(6886)
rpos = sample(1:folds, length(yMat), replace=TRUE)
rposmat = matrix(rpos, nrow=nrow(yMat), ncol=ncol(yMat))
diag(rposmat) = NA
table(rposmat)

# now lets create a list with ten versions of our
# dvs, and in each element of the list the values
# for a particular fold will be set to NA
yMiss = lapply(1:folds, function(fold){
  tmp = yMat
  tmp[which(rposmat==fold)] = NA
  return(tmp) })

# lets make sure to save a version with
# the actual values for easy comparison
yAct = lapply(1:folds, function(fold){
  Y[which(rposmat==fold)] })

# now lets run our various operationalizations
# of lfm on each to see which gives us the
# best out of sample predictive performance

# and while doing so lets be careful in how we set up
# parallelization instructions, keep in mind we want to run
# generate out of sample predictions for each fold and across
# various ks
parInfo = expand.grid(
  fold=1:folds,
  k = possKs )

# run
if(!file.exists(paste0(rpth, 'rmseOut.rda'))){
  cl = makeCluster(folds)
  registerDoParallel(cl)
  rmseOut = foreach(ii=1:nrow(parInfo), .packages=c('amen')) %dopar% {

    # get instructions from parInfo
    fold = parInfo$fold[ii]
    k = parInfo$k[ii]

    # subset to dv
    dv = yMiss[[fold]]

    # run model
    lfmOut = ame(
        Y=dv,
        Xdyad=dyadArr,
        Xrow=sMat,
        Xcol=rMat,
        family='nrm',
        rvar=FALSE,
        cvar=FALSE,
        dcor=FALSE,
        R=k,
        intercept=TRUE,
        symmetric=FALSE,
        seed=6886,
        nscan=10000,
        burn=5000,
        odens=10,
        plot=FALSE,
        print=FALSE,
        gof=TRUE )

    # gather relevant output
    preds = lfmOut$YPM[which(rposmat==fold)]
    act = yAct[[fold]]

    # we have a normal outcome so lets
    # just get an rmse
    out = sqrt( mean( (preds-act)^2 ) )
    return(out) }
  stopCluster(cl)

  #
  save(rmseOut, file=paste0(rpth, file='rmseOut.rda'))
} else { load(paste0(rpth, 'rmseOut.rda')) }

# organize output
parInfo$rmseOut = unlist(rmseOut)

# get average rmse by k
aggregate(list(parInfo$rmseOut), list(parInfo$k), mean)
####
