####
# path setup
require(here)
pth = paste0(here::here(), '/')
dpth = paste0(pth, 'data/')
rpth = paste0(pth, 'results/')
####

####
# packages (all available on cran)
packs = c(
  'amen', # 1.4.4
  'ggplot2', # 3.34
  'tidyr', # 1.1.3
  'reshape2', # 1.4.4
  'gridExtra', # 2.3
  'ggrepel'
)

# load packages
shh = lapply(packs, library, character.only=TRUE)

# helper functions
source(paste0(pth, 'code/helpers.R'))
source(paste0(pth, 'code/ameHelpers.R'))
####

####
# load a longit conflict example
load(paste0(dpth, 'conflictData.rda'))
####

####
# process for ame_rep
# steps here are going to be
# a bit different

# process y
yArr = acast(
	data=conflictData,
	formula=Var1 ~ Var2 ~ year,
  value.var='conflict_events' )

# process xd
ids = c('Var1', 'Var2', 'year')
dyadVars = c('coop_events', 'distance')
dyadVarLong = melt(
  conflictData[,c(ids, dyadVars)], id=c('Var1', 'Var2', 'year'))
dyadArr = acast(
  data=dyadVarLong,
  formula=Var1~Var2~variable~year,
  value.var='value' )

# process nodal variables
nVars = c('gdp','polity')
sendVars = paste0(nVars, '1')
recVars = paste0(nVars, '2')
sendLong = unique(conflictData[,c('Var1', 'year', sendVars)])
sendLong = melt(sendLong, id=c('Var1', 'year'))
sendArr = acast(
  data=sendLong,
  formula=Var1~variable~year,
  value.var='value' )
nodalArr = sendArr
####

####
# run model
if(!file.exists(paste0(rpth, 'fitRep.rda'))){
  fitRep = ame_rep(
    Y=yArr,
    Xdyad=dyadArr,
    Xrow=nodalArr,
    Xcol=nodalArr,
    family='bin',
    symmetric=TRUE,
    intercept=TRUE,
    nvar=TRUE,
    R=2,
    seed=6886,
    plot=FALSE, print=FALSE )
  save(fitRep, file=paste0(rpth, 'fitRep.rda'))
} else { load(paste0(rpth, 'fitRep.rda')) }
####

####
# lets check the output
# output will mostly be in the same format
names(fitRep)

# lets check convergence
paramPlot(fitRep$BETA)

# assessing gof here is going to be a
# bit different, because the network
# has different characteristics over
# time
# the gof object now is in an
# array format
dim(fitRep$GOF)

# lets modify it to see how well we're
# doing at capturing net stats
gof = fitRep$GOF
gof = gof[-4,,] # get rid of cycles again

# add labels
dimnames(gof)[[2]] = dimnames(yArr)[[3]]

# restructure gof
gofList = lapply(dimnames(gof)[[2]], function(t){

  # process
  goft = t(gof[,t,])
  act = goft[1,] # first row is actual
  goft = goft[-1,]
  goft = data.frame(goft)
  goft$time = t
  goft = melt(goft, id='time')

  # add in actual values
  stats = unique(goft$variable)
  goft$actual = NA
  for(stat in stats){
    goft$actual[goft$variable==stat] = act[stat] }

  #
  return(goft)
  })

# merge all together
gofDF = do.call('rbind', gofList)

# viz
ggplot(gofDF, aes(x=factor(time), y=value)) +
  geom_boxplot() +
  geom_point(
    aes(y=actual), color='grey50', shape='diamond', size=4) +
  facet_wrap(~variable, scales='free_y')

# viz diff from actual
gofDF$diff = gofDF$value - gofDF$actual
gofDF = gofDF[gofDF$variable!='dyad.dep',]
ggplot(gofDF, aes(x=factor(time), y=diff)) +
  geom_boxplot() +
  geom_hline(
    yintercept=0,color='grey50', linetype='dotted') +
  labs(
    y='Simulated - Observed'
  ) +
  facet_wrap(~variable, scales='free_y', ncol=2, nrow=2)
####
