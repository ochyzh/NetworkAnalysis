# basic helpers
char = function(x){ as.character(x) }
num = function(x){ as.numeric(char(x)) }

# quick fn to get our adj mats
adjMat = function(data, valVar, actor1Var, actor2Var){

  # create actor vec
  actors = unique(c(data[[actor1Var]], data[[actor2Var]]))
  n = length(actors)

  # set up empty mat
  mat = matrix(NA, nrow=n, ncol=n, dimnames=list(actors,actors))

  # lazy fill in
  for( ii in 1:nrow(data) ){
    a1 = data[[actor1Var]][ii]
    a2 = data[[actor2Var]][ii]
    val = data[[valVar]][ii]
    mat[a1,a2] = val }

  #
  return(mat) }

# fn to calc basic gof stats
gofstats = function(mat){
  rowSD = sd(apply(mat, 1, mean, na.rm=TRUE))
  colSD = sd(apply(mat, 2, mean, na.rm=TRUE))
  recip = cor(c(mat), c(t(mat)),use='pairwise.complete.obs')
  out = c(rowSD=rowSD, colSD=colSD, recip=recip)
  return(out)
}

# fn to calc basic posterior summary stats
summChain = function(x){
  mu = mean(x)
  qt90s = quantile(x, probs=c(0.05, 0.95))
  qt95s = quantile(x, probs=c(0.025, 0.975))
  out = c(
    lo95 = qt95s[1],
    lo90 = qt90s[1],
    mu = mean(x),
    hi95 = qt95s[2],
    hi90 = qt90s[2] )

  #
  return(out) }
