##############################
rm(list=ls())

library(netify) # data processing
library(amen) # srm + lfm
# library(latentnet) # ldm
library(NetMix) # blockmodels

# helper packages
library(ggplot2)
library(reshape2)
###############

###############
# load data
pth = '~/Teaching/icpsr/nets/lectures_24/day12_factor/'
load(paste0(pth, 'gadeData.rda'))

# create binary version of coopActions
data$coopActionsBin = as.numeric(data$coopActions > 0)
###############

###############
# process into a net object
net = netify(
    dyad_data = data, 
    actor1='actor1',
    actor2='actor2',
    symmetric=TRUE,
    weight='coopActionsBin',
    nodal_vars = c(
        'averageId_actor1', 'size_actor1'
        ),   
    dyad_vars = c(
        'ideol_diff', 'powerdiff'
        )
)
###############

###############
# you should do some desc analysis
# a la wtv you learned in nets 1
# or what you learned with olga
# in the beginning
# helper fns from netify:
    # summary
    # summary_actor
    # plot 

# graph level summary
summary(net)

# actor level summary
summary_actor(net)

# across actor dist viz
plot_actor_stats(summary_actor(net))

# highlight specific actors
plot_actor_stats(
    summary_actor(net), 
    across_actor=FALSE, 
    specific_actors = c('ANF', 'ASIM', 'ISIL', 'JAI'))

# plot network
plot(
    net, 
    edge_color='lightgrey',
    remove_isolates=FALSE, 
    add_points=FALSE, 
    add_label=TRUE,
    label_color_var='averageId_actor1',
    label_size_var='size_actor1' 
    ) + 
    labs(
        size='Actor Size',
        color='Average Ideology'
    )
###############    

###############    
# set a seed before starting modeling
set.seed(6886)
###############    

###############    
# so we're consistent
# we'll use a standard set of gof stats
# to compare the mdoels:
# actor heterogeneity
# transitivity
# 3-cycles

# no need for anything else because
# the data below is symmetric

# fn for calculating
calc_gof = function(mat)
{
    actor_mean_sd = sd(rowMeans(mat, na.rm = TRUE), na.rm = TRUE)
    E = mat - mean(mat, na.rm = TRUE)
    D = 1 * (!is.na(E))
    E[is.na(E)] = 0
    triad_dep = c(sum(diag(E %*% E %*% E))/(sum(diag(D %*% D %*% 
        D)) * sd(c(mat), na.rm = TRUE)^3), sum(diag(E %*% t(E) %*% 
        E))/(sum(diag(D %*% t(D) %*% D)) * sd(c(mat), na.rm = TRUE)^3))
    gof = c(actor_mean_sd, triad_dep)
    gof[is.na(gof)] = 0
    names(gof) = c("actor_mean_sd", "cycle_dep", "trans_dep")
    gof
}    

# and using this function lets get the gof stats
# for our observed network right away
gof_obs = calc_gof(net)
###############    

###############
# block models first
# which we'll use the NetMix

# first we need to create a 
# nodal data.frame
nodal_data = unique(
    data[,c('actor1', 
        'averageId_actor1', 
        'size_actor1')] )

# lets run it
blocks_5 = mmsbm(
    coopActionsBin ~ ideol_diff + powerdiff,
    ~ averageId_actor1 + size_actor1,
    senderID = 'actor1',
    receiverID = 'actor2',
    nodeID = 'actor1',
    data.dyad = data,
    data.monad = nodal_data,
    n.blocks = 5, 
    mmsbm.control=list(
        svi=TRUE, # svi stands for stochastic variational inference
        vi_iter=100000 # to adjust iterations for this use vi_iter
    )
)
save(blocks_5, file=paste0(pth, 'blocks_5.rda'))

# assessing convergence in VI isnt about evaluating
# a trace plot. netmix heuristically determines 
# whether the algorithm has converged or not by
# tracking the change in the ELBO
# the ELBO is the evidence lower bound, 
# which is the objective function 
# that the algorithm is trying to maximize
# mmsbm will tell us if the model has converged 
# or not, TRUE means that it has FALSE means
# that you need to increase vi_iter above
blocks_5$converged

# lets assess gof, we'll start by simulating
# nets and calculating gof using our function above
# (note that there is a gof function inside of NetMix
# as well but it wont be useful for us in comparing
# since it calculates its own set of stats)
sim_5 = simulate(blocks_5, nsim=1000, seed=6886)

# sims come out as a list of vectors so we just need to 
# arrange them into an adjmat
# order of dyad values in vector will be determined
# by blocks_5$dyadic.data
dyad_order = blocks_5$dyadic.data[,c('(sid)', '(rid)')]

# now we just need to create a bunch of adjmats from the 
# sims and then for each adj mat calculate the gof stats
# using our calc_gof fn
gof_5 = lapply(sim_5, function(sim_vec){
    # org into df
    sim_df = data.frame(
        sid = dyad_order[,1], rid = dyad_order[,2], 
        sim = sim_vec )
    # turn into adjmat using netify
    sim_net = netify(
        dyad_data = sim_df, 
        actor1='sid', actor2='rid',
        symmetric=TRUE, weight='sim' )
    # calc gof
    calc_gof(sim_net)
})

# org into df
gof_5_df = do.call('rbind', gof_5)

# that was a lot lets turn it into a function
gof_from_mmsbm = function(
    block_model, n_sims=1000, gof_stats=calc_gof, seed=6886
    ){
    # order of dyad values in vector will be determined
    # by model$dyadic.data
    dyad_order = block_model$dyadic.data[,c('(sid)', '(rid)')]
    
    # get simulations
    list_sim_vecs = simulate(block_model, nsim=n_sims, seed=seed)

    # now we just need to create a bunch of adjmats from the 
    # sims and then for each adj mat calculate the gof stats
    # using our calc_gof fn
    gof = lapply(list_sim_vecs, function(sim_vec){
        # org into df
        sim_df = data.frame(
            sid = dyad_order[,1], rid = dyad_order[,2], 
            sim = sim_vec )
        # turn into adjmat using netify
        sim_net = netify(
            dyad_data = sim_df, 
            actor1='sid', actor2='rid',
            symmetric=TRUE, weight='sim' )
        # calc gof
        gof_stats(sim_net)
    })
    
    # org into df
    gof_df = do.call('rbind', gof)
    return(gof_df) }

# calculate gof for sims
gof_5_df = gof_from_mmsbm(blocks_5)

# compare with observed
apply(gof_5_df, 2, function(x){ quantile(x, c(0.025, 0.5, 0.975)) })
gof_obs
# seems okay, except for actor heteogeneity

# lets look at the results
summary(blocks_5)

# visualize the block connectivity matrix
plot(blocks_5)

# to see which nodes got assigned to which blocks
# for the purpose of measurement and further
# understanding of the results
blocks_5$MixedMembership
# each row here indicates the probability of
# a node being in block 1, 2, 3, 4, 5. sum 
# across the columns will be one.

# what's clear looking here is that the model
# is not doing a good job in assigning nodes
# to diff blocks, there's almost a uniform
# probabiltiy of most actors in being
# in any of the blocks, here's a stacked
# bar plot that further shows this
ggdata = blocks_5$MixedMembership
ggdata = data.frame(ggdata)
ggdata$block = 1:5
ggdata = reshape2::melt(ggdata, id.vars='block')    
ggplot(ggdata, aes(x=variable, y=value, fill=block)) + 
    geom_bar(stat='identity') + 
    theme_minimal() + 
    labs(x='', y='Probability', fill='Block')

# this could be a useful fn as well
viz_block_assign = function(block_model){
    ggdata = block_model$MixedMembership
    ggdata = data.frame(ggdata)
    ggdata$block = factor(1:block_model$n_blocks)
    ggdata = reshape2::melt(ggdata, id.vars='block')    
    ggplot(ggdata, aes(x=variable, y=value, fill=block)) + 
        geom_bar(stat='identity') + 
        theme_minimal() +
        theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
        labs(x='', y='Probability', fill='Block') }
viz_block_assign(blocks_5)

# lets try with 3 blocks, to see if we can better
# differentiate actors
# lets run it
blocks_3 = mmsbm(
    coopActionsBin ~ ideol_diff + powerdiff,
    ~ averageId_actor1 + size_actor1,
    senderID = 'actor1',
    receiverID = 'actor2',
    nodeID = 'actor1',
    data.dyad = data,
    data.monad = nodal_data,
    n.blocks = 3, 
    mmsbm.control=list(
        svi=TRUE, 
        vi_iter=100000
    )
)
save(blocks_3, file=paste0(pth, 'blocks_3.rda'))

# check convergence
blocks_3$converged

# calculate gof for sims
gof_3_df = gof_from_mmsbm(blocks_3)

# compare with observed
apply(gof_3_df, 2, function(x){ quantile(x, c(0.025, 0.5, 0.975)) })
gof_obs
# seems okay, except for actor heteogeneity

# lets look at the results
summary(blocks_3)

# visualize the block connectivity matrix
plot(blocks_3)

# not looking that promizing, lets look
# at the mixed membershp matrix again
viz_block_assign(blocks_3)

# yeah this is useless too

# maybe the dyadic vars are absorbing all the 
# variation? lets try running a null model
blocks_3_null = mmsbm(
    coopActionsBin ~ 1,
    ~ averageId_actor1 + size_actor1,
    senderID = 'actor1',
    receiverID = 'actor2',
    nodeID = 'actor1',
    data.dyad = data,
    data.monad = nodal_data,
    n.blocks = 3, 
    mmsbm.control=list(
        svi=TRUE, 
        vi_iter=100000
    )
)
save(blocks_3_null, file=paste0(pth, 'blocks_3_null.rda'))

# check block assignments
viz_block_assign(blocks_3_null)
# nope still mostly useless
# ASIM falls into block 1 a bit more
# but hard to tell anything diff
# about the rest of the actors

# blockmodel just does not seem
# a good fit for this data

# lets move onto amen
###############

###############
# srm + lfm
# we'll use the amen package
data_amen = prep_for_amen(net)

# run model
vecs_2 = ame(
    Y = data_amen$Y,
    Xdyad = data_amen$Xdyad,
    Xrow = data_amen$Xrow,
    family='bin',
    R = 2, 
    symmetric = TRUE,
    seed=6886,
    nscan=10000,
    burn=50000,
    odens=5,
    plot=FALSE, # when running long chain set to F
    print=FALSE # when running long chain set to F
)
save(vecs_2, file=paste0(pth, 'vecs_2.rda'))

# evaluate convergence, pull out betas
beta = vecs_2$BETA

# lets load in the coda 
# package to help evaluate convergence
library(coda)

# create a mcmc object using the mcmc
# function from the coda package
beta_mcmc = mcmc(beta)
plot(beta_mcmc)
# could run for longer but
# decent enough to start exploring

# pull out gof stats
gof_ame = vecs_2$GOF
gof_ame = [-1,]
apply(gof_ame, 2, function(x){ quantile(x, c(0.025, 0.5, 0.975)) })
gof_obs
# looks good across all dims

# summarize coefficients
summary(vecs_2)

# look at the additive effects
sort(vecs$APM)

# circle plot
par(mfrow=c(1,1))
circplot(
    Y=data_amen$Y, 
    U=vecs_2$U
)

# and if we wanted to extract
# distances between actors in vector 
# space we can pull out the U matrix
u_mat = vecs_2$U

# and then since lfm is locating 
# points in a vector space we need to
# use cosine distance
# lets write a fn to estimate cosine dist
cos_dist = function(x, y) {
    1 - sum(x * y) / (sqrt(sum(x^2)) * sqrt(sum(y^2))) }

# create mat to store results
n = nrow(u_mat)
u_dist = matrix(NA, n, n)
rownames(u_dist) = rownames(u_mat)
colnames(u_dist) = rownames(u_mat)

# fill in
for (ii in 1:n) {
    for (jj in 1:n) {
        u_dist[ii, jj] = cos_dist(u_mat[ii, ], u_mat[jj, ])
    }
}

# check out first few rows/cols
u_dist[1:3,1:3]
###############

###############
# latent distance model
library(latentnet)

# prep for statnet
data_statnet = prep_for_statnet(net)

# extract dyadic covariates into
# separate matrices
ideol_diff = attributes(net)$dyad_data[[1]][,,'ideol_diff']
powerdiff = attributes(net)$dyad_data[[1]][,,'powerdiff']

# run ldm
ldm_2 = ergmm(
    data_statnet ~ euclidean(d=2) + 
        nodecov('averageId_actor1') +
        nodecov('size_actor1') +
        edgecov(ideol_diff) +
        edgecov(powerdiff),
    control=ergmm.control(
        burnin=500000 # burn in period
        # sample.size=5000, # iters for sampler
        # interval=10 # output density
    )
)
save(ldm_2, file=paste0(pth, 'ldm_2.rda'))

# we got a warning, so we should def
# run for longer before finalizing things
# but lets look at the trace plots
# to see if we can do prelim stuff
mcmc.diagnostics(ldm_2)
# yup these look good for some init
# looks

# lets look at the results
summary(ldm)

# lets look at gof as we have 
# with oether latent var mods
ldm_preds = simulate(ldm, nsim=1000)

# lets get just the nets
ldm_preds_nets = ldm_preds$networks

# first step in this is 
# to convert to sociomatrices
ldm_preds_mats = lapply(ldm_preds_nets, as.sociomatrix)

# lets see how well the ldm did with gof stats
gof_ldm = lapply(ldm_preds_mats, calc_gof)
gof_ldm = do.call('rbind', gof_ldm)

#
apply(gof_ldm, 2, function(x){ quantile(x, c(0.025, 0.5, 0.975)) })
gof_obs
# looks good across all dims

# visualize the mds space
plot(ldm_2, labels=TRUE)

# if you wanted to pull out
# distances between nodes
# in latent space

# positions are located here
pos_mat = ldm_2$mcmc.pmode$Z

# add labels
rownames(pos_mat) = rownames(net)

# and then since this is a euclidean
# space we can just use dist
# to calculate euclidean dist
# between every pair of obs
dist_mat = as.matrix(dist(pos_mat))
###############